package com.example.sirapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.View;
import android.net.Uri;
import android.widget.Button;




public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ConstraintLayout constraintLayout = findViewById(R.id.layout);
        AnimationDrawable animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        animationDrawable.setEnterFadeDuration(2000);
        animationDrawable.setExitFadeDuration(4000);
        animationDrawable.start();


        String path;

        Button buttonGlowEye = (Button) findViewById(R.id.button);
        buttonGlowEye.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                String url = "http://192.168.43.154/glowEyes";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });
        Button buttonRoleEyes = (Button) findViewById(R.id.button3);
        buttonRoleEyes.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                String url = "http://192.168.43.154/roundSpin";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });
        Button buttonUpDown = (Button) findViewById(R.id.button4);
        buttonUpDown.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                String url = "http://192.168.43.154/crazySpin";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);

            }
        });


        //new GetUrlContentTask().execute(sUrl);

    }

    }


